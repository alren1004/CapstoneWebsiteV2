/* dCodes Framework: (c) TemplateAccess */

// <![CDATA[

$(function(){
	$('.row1').adipoli({
		'startEffect' : 'normal',
		'hoverEffect' : 'popout'
	});
	$('.row2').adipoli({
		'startEffect' : 'overlay',
		'hoverEffect' : 'sliceDown'
	});
	$('.row3').adipoli({
		'startEffect' : 'transparent',
		'hoverEffect' : 'boxRandom'
	});
	$('.row4').adipoli({
		'startEffect' : 'overlay',
		'hoverEffect' : 'foldLeft'
	});
	$('.row5').adipoli({
		'startEffect' : 'transparent',
		'hoverEffect' : 'boxRainGrowReverse'
	});
	$('.row6').adipoli({
		'startEffect' : 'grayscale',
		'hoverEffect' : 'normal'
	});
});	

// ]]>