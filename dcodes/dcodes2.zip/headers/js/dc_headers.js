/* dCodes Framework: (c) TemplateAccess */

// <![CDATA[
// JavaScript Document

$(function() {

  //prepend span tag
  $(".jquery h1").prepend("<span></span>");

});

// ]]>